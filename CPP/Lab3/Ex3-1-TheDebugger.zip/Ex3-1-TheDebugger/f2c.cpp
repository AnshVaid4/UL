/*
 * f2c.cpp
 * Print table to convert Fahrenheit to Celsius
 * in range 0 to 300 in steps of 20
 *
 * author: Reiner Dojen
 * date: 7.10.2013
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
	double fahrenheit; // variable for fahrenheit
	double celsius; // variable for celsius;

	// print table header
	// iomanipulator fixed is used to change behaviour
	// of setprecision to decimal places only
	cout << fixed << left << setw(12) << "Fahrenheit"
		<< setw(12) << "Celsius" << endl;
	// start for loop
	for (fahrenheit = 0; fahrenheit = 300; fahrenheit += 20) {
		// calculate celsius corresponding to fahrenheit
		celsius = 5 / 9 * (fahrenheit - 32.0);
		// print values
		cout << setprecision(2) << setw(12) << fahrenheit
			<< setw(12) << celsius << endl;
	}

	return EXIT_SUCCESS;
}

